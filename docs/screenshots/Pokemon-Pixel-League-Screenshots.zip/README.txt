﻿POKEMON PIXEL LEAGUE - PRESENTATION SCREENSHOTS

Five 1920 x 1080 PNG captures from the actual local game:
01 - Dashboard and team challenge
02 - Pokemon partner selection
03 - Moonlit village gameplay
04 - Waterfall Quarter gameplay
05 - Gengar boss encounter (clean view with the interface hidden)

The later practice scenes were positioned for the screenshots to show different environments and the boss. These are not official competition results.

Suggested slide order: Dashboard, Partner selection, Moonlit adventure, Waterfall Quarter, Boss encounter.
